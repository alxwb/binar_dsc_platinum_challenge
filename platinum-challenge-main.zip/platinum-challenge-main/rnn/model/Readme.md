add RNN model here (.h5)
