add LSTM model here (.h5)
